/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function handleButtonClick(buttonNumber) {
  if (buttonNumber === 1) {
    alert('Button 1 clicked!');
    // Add functionality for Button 1 click
  } else if (buttonNumber === 2) {
    alert('Button 2 clicked!');
    // Add functionality for Button 2 click
  }
}
